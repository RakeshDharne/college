import csv
from typing import List

# Function to read CSV file and store data
def read_csv(filename: str) -> List[List[str]]:
    data = []
    try:
        with open(filename, newline='') as file:
            reader = csv.reader(file)
            for row in reader:
                data.append(row)
    except Exception as e:
        print(f"Error opening file: {filename}, {e}")
    return data

# Function to write data to a CSV file
def write_csv(filename: str, data: List[List[str]]):
    try:
        with open(filename, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerows(data)
    except Exception as e:
        print(f"Error opening file for writing: {filename}, {e}")

# Function to find correlation between two entities
def find_correlation(data: List[List[str]], tid1: int, tid2: int) -> float:
    tid1_count = 0
    tid2_count = 0
    total_common_count = 0

    # Loop through columns 1 to 7 (adjusted for 0-based indexing)
    for j in range(1, 8):  # Columns 1 to 7
        if data[tid1][j] == "Y":
            tid1_count += 1
        if data[tid2][j] == "Y":
            tid2_count += 1
        if data[tid1][j] == "Y" and data[tid2][j] == "Y":
            total_common_count += 1

    if tid1_count == 0 or tid2_count == 0:
        return 0.0

    return total_common_count / (tid1_count * tid2_count)

def main():
    # Read input data from CSV file
    sheet = read_csv("9.correlation\Correlation_Input.csv")

    if len(sheet) < 2:
        print("Not enough data to compute correlation.")
        return  # Exit if there's not enough data

    n = len(sheet) - 1  # Number of rows (excluding header)

    # Store data for output
    output_data = [["Item 1 with tid", "Item 2 with tid", "Correlation coefficient", "Type of correlation"]]

    # Iterate through pairs of entities
    for i in range(1, n + 1):  # Start from 1 since 0 is header
        for j in range(i + 1, n + 1):
            ans = find_correlation(sheet, i, j)
            if ans == 0:
                verdict = "No relationship between entities"
            elif ans < 0:
                verdict = "Negative correlation"
            elif ans > 0:
                verdict = "Positive correlation"
            else:
                verdict = "Not defined"

            print(f"Correlation ratio {i} & {j} = {ans:.4f} {verdict}")

            # Prepare row for output
            row = [str(i), str(j), f"{ans:.4f}", verdict]
            output_data.append(row)

    # Write output data to a CSV file
    write_csv("9.correlation/Correlation_output.csv", output_data)

if __name__ == "__main__":
    main()