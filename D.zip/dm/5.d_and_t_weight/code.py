import pandas as pd

def main():
    # Read the input CSV file
    try:
        df = pd.read_csv("5.d_and_t_weight/exp4_input.csv", header=None)
    except FileNotFoundError:
        print("Couldn't open file")
        return

    # Initialize data structures
    classrowcol_map = {}
    col_map = {}
    row_map = {}

    # Process the DataFrame
    for index, row in df.iterrows():
        if index == 0:  # Skip the header row
            continue

        row_key = row[0]
        col_key = row[1]
        count = int(row[2])

        # Update the maps
        if row_key not in classrowcol_map:
            classrowcol_map[row_key] = {}
        classrowcol_map[row_key][col_key] = count

        col_map[col_key] = col_map.get(col_key, 0) + count
        row_map[row_key] = row_map.get(row_key, 0) + count

    # Print the class-row-column map
    for r in row_map:
        for c in col_map:
            print(f"{r}-{c}: {classrowcol_map[r].get(c, 0)}")

    # Print row sums
    for r in row_map:
        print(f"{r} -> {row_map[r]}")

    # Print column sums
    for c in col_map:
        print(f"{c} -> {col_map[c]}")

    # Calculate total sums
    col_sum = sum(col_map.values())
    row_sum = sum(row_map.values())
    print(f"colSum: {col_sum}")
    print(f"rowSum: {row_sum}")

    # Write output to CSV file
    with open("5.d_and_t_weight/exp4_output.csv", "w") as fw:
        fw.write("Column\\row , ,Bollywood ,, ,Tollywood ,, ,Total,,, \n")
        fw.write(" Count, t - weight, d - weight, Count, t - weight, d - weight, Count, t - weight, d - weight \n")

        for r in row_map:
            fw.write(f"{r},")
            for c in col_map:
                count_value = classrowcol_map[r].get(c, 0)
                fw.write(f"{count_value},")
                fw.write(f"{(count_value / row_map[r]) * 100:.2f}%,")
                fw.write(f"{(count_value / col_map[c]) * 100:.2f}%,")
            fw.write(f"{row_map[r]}, {(row_map[r] / row_map[r]) * 100:.2f}%, {(row_map[r] / col_sum) * 100:.2f}%\n")

        fw.write("Total ,")
        for c in col_map:
            fw.write(f"{col_map[c]},")
            fw.write(f"{(col_map[c] / col_sum) * 100:.2f}%,")
            fw.write(f"{(col_map[c] / col_map[c]) * 100:.2f}%,")
        fw.write(f"{col_sum}, 100%, 100%\n")

if __name__ == "__main__":
    main()