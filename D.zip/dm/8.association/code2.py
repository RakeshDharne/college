import csv
from itertools import combinations
from collections import defaultdict

def wordsof(s):
    return [word for word in s.split() if word.isalnum()]

def combine(arr, miss):
    return ' '.join(arr[i] for i in range(len(arr)) if i != miss)

def apriori_gen(sets, k):
    set2 = set()
    sorted_sets = sorted(sets)
    for i in range(len(sorted_sets)):
        for j in range(i + 1, len(sorted_sets)):
            v1 = wordsof(sorted_sets[i])
            v2 = wordsof(sorted_sets[j])
            if v1[:k - 1] == v2[:k - 1]:
                new_item = ' '.join(sorted(v1 + [v2[k - 1]]))
                if all(combine(new_item.split(), i) in sets for i in range(len(new_item.split()))):
                    set2.add(new_item)
    return set2

def count_occurrences(v, datatable):
    count = 0
    for s in datatable:
        if all(x in s for x in v):
            count += 1
    return count

def subsets(items, v1, v2, idx, datatable, minfre, fw1):
    if idx == len(items):
        if not v1 or not v2:
            return
        count1 = count_occurrences(items, datatable)
        count2 = count_occurrences(v1, datatable)
        conf = (count2 / count1) * 100 if count1 > 0 else 0
        if conf >= confidence:
            fw1.write("{ " + " ".join(v1) + "} -> { " + " ".join(v2) + "} , " + str(conf) + "\n")
        return
    subsets(items, v1 + [items[idx]], v2, idx + 1, datatable, minfre, fw1)
    subsets(items, v1, v2 + [items[idx]], idx + 1, datatable, minfre, fw1)

def generate_association_rules(freq_items, datatable, minfre, fw1):
    for item in freq_items:
        items = wordsof(item)
        subsets(items, [], [], 0, datatable, minfre, fw1)

def main():
    with open("8.association/exp7_input.csv", "r") as fin:
        datatable = []
        products = set()
        freq = defaultdict(int)

        print("Enter Support % : ", end="")
        minfre = float(input())
        print("Enter Confidence % : ", end="")
        global confidence
        confidence = float(input())

        for line in fin:
            arr = wordsof(line.strip())
            tmpset = set(arr)
            datatable.append(tmpset)
            for item in tmpset:
                products.add(item)
                freq[item] += 1

        print("No of transactions:", len(datatable))
        minfre = minfre * len(datatable) / 100
        print("Min frequency:", minfre)

        products = {item for item in products if freq[item] >= minfre}

        i = 1
        print(f"\nFrequent {i}-item set :")
        for item in products:
            print(f"{{ {item} }} {freq[item]}")

        prev = products.copy()
        while True:
            cur = apriori_gen(prev, i + 1)
            if not cur:
                break
            for item in cur:
                arr = wordsof(item)
                tot = count_occurrences(arr, datatable)
                if tot >= minfre:
                    freq[item] += tot
                else:
                    cur.remove(item)

            if not cur:
                break

            print(f"\n\nFrequent {i + 1}-item set :")
            for item in cur:
                print(f"{{ {item} }} {freq[item]}")
            prev = cur
            i += 1

        with open("8.association/exp7_output.csv", "w") as fw1:
            generate_association_rules(prev, datatable, minfre, fw1)

if __name__ == "__main__":
    main()