import csv
import math

def distance(x1, y1, x2, y2):
    return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

def main():
    points = []
    
    # Read input data from CSV file
    with open("10.distance_cluster/cluster_input.csv", "r") as infile:
        reader = csv.reader(infile)
        next(reader)  # Skip header
        for row in reader:
            x = int(row[1])
            y = int(row[2])
            points.append((x, y))

    n = len(points)

    # Calculate the midpoint
    x_sum = sum(p[0] for p in points)
    y_sum = sum(p[1] for p in points)
    mid_x = x_sum / n
    mid_y = y_sum / n

    print(f"Mid Point: ({mid_x}, {mid_y})")

    # Prepare output data
    output_data = [["", "p1", "p2", "p3", "p4", "C"]]

    # Calculate distances and prepare the output
    for i in range(n):
        row = [f"p{i + 1}"]
        for j in range(i + 1):
            if points[i] == points[j]:
                row.append(0)
            else:
                dis = distance(points[i][0], points[i][1], points[j][0], points[j][1])
                row.append(dis)
        output_data.append(row)

    # Calculate distances from the midpoint
    output_data.append(["C"])
    nearest_distance = float('inf')
    nearest_index = -1
    new_center_x = new_center_y = 0

    for i in range(n):
        d = distance(mid_x, mid_y, points[i][0], points[i][1])
        print(f"Distance of p{i + 1} from centre: {d}")
        output_data[-1].append(d)
        
        if d < nearest_distance:
            nearest_distance = d
            nearest_index = i
            new_center_x, new_center_y = points[i]

    print(f"Nearer Distance: {nearest_distance}")
    print(f"Nearest point from Centre is: p{nearest_index + 1}")

    # New center output
    output_data.append(["", "p1", "p2", "p3", "p4"])
    for i in range(n):
        row = [f"p{i + 1}"]
        for j in range(i + 1):
            if points[i] == points[j]:
                row.append(0)
            else:
                dis = distance(points[i][0], points[i][1], points[j][0], points[j][1])
                row.append(dis)
        output_data.append(row)

    # Output for new center
    output_data.append([f"p{nearest_index + 1} (New Center)"])
    for i in range(n):
        d = distance(new_center_x, new_center_y, points[i][0], points[i][1])
        print(f"Distance of p{i + 1} from p{nearest_index + 1}: {d}")
        output_data[-1].append(d)

    # Write output data to CSV file
    with open("10.distance_cluster/cluster_output.csv", "w", newline='') as outfile:
        writer = csv.writer(outfile)
        writer.writerows(output_data)

if __name__ == "__main__":
    main()