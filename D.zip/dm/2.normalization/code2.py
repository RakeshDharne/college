import numpy as np
import pandas as pd

def min_max_normalization(data):
    min_val = np.min(data)
    max_val = np.max(data)
    normalized = (data - min_val) / (max_val - min_val)
    return normalized

def z_score_normalization(data):
    mean = np.mean(data)
    std_dev = np.std(data)
    normalized = (data - mean) / std_dev
    return normalized

def read_csv(filename):
    # Read CSV file and return a numpy array of data
    data = pd.read_csv(filename, header=None)
    return data.values.flatten()  # Flatten to a 1D array

def write_to_file(filename, min_max_normalized, z_score_normalized):
    with open(filename, 'w') as out_file:
        out_file.write("Min-Max Normalized Data:\n")
        out_file.write(" ".join(map(str, min_max_normalized)) + "\n\n")
        
        out_file.write("Z-Score Normalized Data:\n")
        out_file.write(" ".join(map(str, z_score_normalized)) + "\n")

def main():
    input_filename = "data.csv"  # Input CSV file name
    output_filename = "normalized_output.txt"  # Output file name

    data = read_csv("2.normalization/data.csv")

    min_max_normalized = min_max_normalization(data)
    z_score_normalized = z_score_normalization(data)

    # Write results to output file
    write_to_file(output_filename, min_max_normalized, z_score_normalized)

    print(f"Normalization results have been written to {output_filename}")

if __name__ == "__main__":
    main()