import pandas as pd
import math

def main():
    # Read the input CSV file
    try:
        df = pd.read_csv("4.info_gain/exp3_input.csv", header=None)
    except FileNotFoundError:
        print("Error in opening input file: exp3_input.csv")
        return

    # Prepare to write output to a file
    output_file = open("4.info_gain/output.txt", "w")

    # Prompt the user for the child column number
    choice = int(input("Enter Child Column Number: "))
    output_file.write(f"Enter Child Column Number: {choice}\n")

    parent = {}
    child = {}

    # Process each row in the DataFrame
    for index, row in df.iterrows():
        if index == 0:  # Skip the header row
            continue

        day = row[0]
        level = row[1]
        routine = row[2]
        play_game = row[3]
        value = row[4]

        # Determine the child name based on user choice
        if choice == 1:
            child_name = day
        elif choice == 2:
            child_name = level
        elif choice == 3:
            child_name = routine
        elif choice == 4:
            child_name = value
        else:
            child_name = routine

        # Update parent counts
        parent[play_game] = parent.get(play_game, 0) + 1

        # Update child counts
        if child_name not in child:
            child[child_name] = {}
        child[child_name][play_game] = child[child_name].get(play_game, 0) + 1

    # Calculate parent entropy
    pos = parent.get("Yes", 0)
    neg = parent.get("No", 0)
    total = pos + neg

    parent_entropy = 0
    if total > 0:
        parent_entropy = -((pos / total) * math.log2(pos / total) +
                           (neg / total) * math.log2(neg / total))

    output_file.write(f"Parent Entropy: {parent_entropy}\n")

    # Calculate child entropy
    child_entropy = 0
    for val, games in child.items():
        pR = games.get("Yes", 0)
        nR = games.get("No", 0)
        tR = pR + nR
        if tR > 0:
            child_entropy += -((pR + nR) / total) * \
                             ((pR / tR) * math.log2(pR / tR) + (nR / tR) * math.log2(nR / tR))

    output_file.write(f"Child Entropy * Their proportion: {child_entropy}\n")
    output_file.write(f"Info gain: {parent_entropy - child_entropy}\n")

    # Close the output file
    output_file.close()

if __name__ == "__main__":
    main()