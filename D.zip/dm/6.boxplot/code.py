import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

class Summary:
    def __init__(self, min_val, q1, median, q3, max_val, iqr):
        self.min = min_val
        self.Q1 = q1
        self.median = median
        self.Q3 = q3
        self.max = max_val
        self.IQR = iqr

def five_number_summary(column):
    sorted_col = sorted(column)
    n = len(sorted_col)

    min_val = sorted_col[0]
    max_val = sorted_col[-1]

    # Calculate median
    if n % 2 == 0:
        median = (sorted_col[n // 2 - 1] + sorted_col[n // 2]) / 2.0
    else:
        median = sorted_col[n // 2]

    # Calculate Q1
    lower_half = sorted_col[:n // 2]
    if len(lower_half) % 2 == 0:
        Q1 = (lower_half[len(lower_half) // 2 - 1] + lower_half[len(lower_half) // 2]) / 2.0
    else:
        Q1 = lower_half[len(lower_half) // 2]

    # Calculate Q3
    upper_half = sorted_col[(n + 1) // 2:]
    if len(upper_half) % 2 == 0:
        Q3 = (upper_half[len(upper_half) // 2 - 1] + upper_half[len(upper_half) // 2]) / 2.0
    else:
        Q3 = upper_half[len(upper_half) // 2]

    IQR = Q3 - Q1
    return Summary(min_val, Q1, median, Q3, max_val, IQR)

def read_csv(file_path):
    data = pd.read_csv(file_path, header=None)
    return data.values.tolist()  # Convert DataFrame to list of lists

def process_csv(input_file_path, output_file_path):
    data = read_csv(input_file_path)

    rows = len(data)
    columns = len(data[0]) if rows > 0 else 0  # Check for empty data

    if rows == 0 or columns == 0:
        print("No data found!")
        return

    # Transpose the data to process each column
    transposed = list(zip(*data))  # Transpose using zip

    # Create output file stream
    with open(output_file_path, 'w') as output_file:
        # Calculate and write summary for each column
        for i in range(columns):
            column = list(transposed[i])  # Get the column values
            summary = five_number_summary(column)
            output_file.write(f"Summary for Column {i + 1}:\n")
            output_file.write(f"Min: {summary.min}\n")
            output_file.write(f"Q1: {summary.Q1}\n")
            output_file.write(f"Median: {summary.median}\n")
            output_file.write(f"Q3: {summary.Q3}\n")
            output_file.write(f"Max: {summary.max}\n")
            output_file.write(f"IQR: {summary.IQR}\n\n")

    # Generate box plot
    plt.figure(figsize=(10, 6))
    # sns.boxplot(data=data)  # Create box plot using the original data
    plt.title('Box Plot of Data')
    plt.xlabel('Columns')
    plt.ylabel('Values')
    # plt.savefig('box_plot.png')  # Save the box plot as an image
    # plt.show()  # Display the box plot

if __name__ == "__main__":
    input_file = "6.boxplot/data.csv"       # Input CSV file path
    output_file = "6.boxplot/summary.txt"    # Output summary file path
    process_csv(input_file, output_file)