import csv
import math
from collections import defaultdict

# Function to calculate the mean of a list
def calculate_mean(values):
    return sum(values) / len(values)

# Function to calculate the standard deviation of a list
def calculate_std_dev(values, mean):
    return math.sqrt(sum((value - mean) ** 2 for value in values) / len(values))

# Gaussian Probability Density Function for numerical data
def calculate_gaussian_probability(x, mean, std_dev):
    return (1 / (math.sqrt(2 * math.pi) * std_dev)) * math.exp(-((x - mean) ** 2) / (2 * std_dev ** 2))

# Function to read CSV file and parse the data
def read_csv(filename):
    data = []
    with open(filename, mode='r') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            data.append(row)
    return data

# Function to write output to CSV file
def write_csv(filename, log_data):
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        for line in log_data:
            writer.writerow([line])

# Function to train Naive Bayes for categorical and numerical data
def train_naive_bayes(data, target_col):
    categorical_counts = defaultdict(lambda: defaultdict(lambda: defaultdict(float)))
    numerical_stats = defaultdict(lambda: defaultdict(list))
    class_counts = defaultdict(int)

    for row in data[1:]:
        target_class = row[target_col]
        class_counts[target_class] += 1

        for j, value in enumerate(row):
            if j == target_col:
                continue

            if value.replace('.', '', 1).isdigit():  # Numerical data
                numerical_stats[target_class][j].append(float(value))
            else:  # Categorical data
                categorical_counts[target_class][j][value] += 1

    return categorical_counts, numerical_stats, class_counts

# Function to predict class for a new instance and log all probabilities to CSV
def predict_naive_bayes(data, target_col, categorical_counts, numerical_stats, class_counts, instance):
    total_samples = len(data) - 1
    best_prob = -1
    best_class = None
    log_data = ["Class,Prior Probability,Feature Probabilities,Total Probability"]

    for target_class, class_count in class_counts.items():
        class_prob = class_count / total_samples
        log_line = f"{target_class},{class_prob}"

        for j, feature_value in enumerate(instance):
            if j == target_col:
                continue

            if feature_value.replace('.', '', 1).isdigit():  # Numerical feature
                values = numerical_stats[target_class][j]
                mean = calculate_mean(values)
                std_dev = calculate_std_dev(values, mean)
                feature_prob = calculate_gaussian_probability(float(feature_value), mean, std_dev)
                class_prob *= feature_prob
                log_line += f",{feature_prob}"
            else:  # Categorical feature
                feature_prob = categorical_counts[target_class][j].get(feature_value, 1.0 / (class_count + len(categorical_counts[target_class][j])))
                class_prob *= feature_prob
                log_line += f",{feature_prob}"

        log_line += f"={class_prob}"
        log_data.append(log_line)

        if class_prob > best_prob:
            best_prob = class_prob
            best_class = target_class

    log_data.append(f"Predicted Class: {best_class}")
    return best_class, log_data

def main():
    input_file = "13.bayes/input.csv"
    data = read_csv(input_file)

    # User provides the index of the target (class) column
    target_col = int(input("Enter the index of the target column (0-indexed): "))

    # Train Naive Bayes
    categorical_counts, numerical_stats, class_counts = train_naive_bayes(data, target_col)

    # Ask user for a new instance for prediction
    new_instance = []
    print("Enter the values for the new instance:")
    for i, column_name in enumerate(data[0]):
        if i == target_col:
            continue
        new_instance.append(input(f"{column_name}: "))

    # Predict the class and log intermediate results
    predicted_class, log_data = predict_naive_bayes(data, target_col, categorical_counts, numerical_stats, class_counts, new_instance)

    # Write results to output.csv
    output_file = "13.bayes\output.csv"
    write_csv(output_file, log_data)

    print(f"Predicted Class: {predicted_class}")
    print(f"Results and intermediate calculations written to {output_file}")

if __name__ == "__main__":
    main()
