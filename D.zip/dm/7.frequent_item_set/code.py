import csv
from collections import defaultdict, deque

def wordsof(string):
    """Extracts words from a string, filtering out non-alphanumeric characters."""
    return [word for word in string.split() if word.isalnum()]

def combine(arr, miss):
    """Combines words in the array, excluding the word at the index 'miss'."""
    return ' '.join(arr[i] for i in range(len(arr)) if i != miss)

def cloneit(arr):
    """Creates a duplicate of a set."""
    return set(arr)

def apriori_gen(sets, k):
    """Generates candidate itemsets of size k from the frequent itemsets of size k-1."""
    set2 = set()
    sets_list = list(sets)
    for i in range(len(sets_list)):
        for j in range(i + 1, len(sets_list)):
            v1 = wordsof(sets_list[i])
            v2 = wordsof(sets_list[j])
            if v1[:k-1] == v2[:k-1]:  # Check if first k-1 items are equal
                v1.append(v2[k-1])
                v1 = sorted(v1)  # Sort to maintain order
                candidate = combine(v1, -1)
                if all(combine(v1, i) in sets for i in range(len(v1))):
                    set2.add(candidate)
    return set2

def main():
    # Read input from CSV file
    input_file = "7.frequent_item_set/exp6_input.csv"
    transactions = []
    freq = defaultdict(int)
    products = set()

    # Read the minimum frequency percentage
    min_freq_percentage = float(input("Frequency %: "))
    
    with open(input_file, 'r') as fin:
        reader = csv.reader(fin)
        for row in reader:
            transaction = set(wordsof(' '.join(row)))
            transactions.append(transaction)
            for item in transaction:
                products.add(item)
                freq[item] += 1

    print("No of transactions:", len(transactions))
    min_freq = min_freq_percentage * len(transactions) / 100
    print("Min frequency:", min_freq)

    # Remove infrequent products
    products = {item for item in products if freq[item] >= min_freq}

    # Print frequent 1-itemsets
    print("\nFrequent 1-item set:")
    for item in products:
        print(f"{{{item}}} {freq[item]}")

    pass_num = 1
    i = 2
    prev = cloneit(products)

    while True:
        cur = apriori_gen(prev, i - 1)
        if not cur:
            break

        q = deque()
        for item in cur:
            arr = wordsof(item)
            total = sum(1 for transaction in transactions if all(a in transaction for a in arr))
            if total >= min_freq:
                freq[item] += total
            else:
                q.append(item)

        while q:
            cur.remove(q.popleft())

        if not cur:
            break

        print(f"\n\nFrequent {pass_num} -item set:")
        for item in cur:
            print(f"{{{item}}} {freq[item]}")
        
        prev = cloneit(cur)
        pass_num += 1
        i += 1

    # Write frequent itemsets to output file
    with open("7.frequent_item_set/exp6_input.csv", 'w') as fw:
        for item in prev:
            fw.write(f"{{{item}}}\n")

if __name__ == "__main__":
    main()