import csv
import math

# Function to calculate entropy
def calculate_entropy(yes, no):
    total = yes + no
    if total == 0:
        return 0
    p_yes = yes / total
    p_no = no / total

    entropy = 0
    if p_yes > 0:
        entropy -= p_yes * math.log2(p_yes)
    if p_no > 0:
        entropy -= p_no * math.log2(p_no)

    return entropy

# Function to calculate Gini Index
def calculate_gini(yes, no):
    total = yes + no
    if total == 0:
        return 0
    p_yes = yes / total
    p_no = no / total

    gini = 1 - (p_yes ** 2 + p_no ** 2)
    return gini

# Function to read CSV file and parse the data
def read_csv(filename):
    data = []
    with open(filename, mode='r') as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            data.append(row)
    return data

# Function to write result to CSV file
def write_csv(filename, log_data):
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        for line in log_data:
            writer.writerow([line])

# Function to check if a string is numeric
def is_numeric(value):
    try:
        float(value)
        return True
    except ValueError:
        return False

# Function to split and calculate for numerical data
def calculate_for_numerical(data, feature_col, target_col, target_count, log_data, parent_entropy, total_samples):
    unique_values = set(float(row[feature_col]) for row in data[1:])
    best_info_gain = -1
    best_split = None
    best_final_gini = 0

    for split_point in unique_values:
        left_yes = left_no = right_yes = right_no = 0

        for row in data[1:]:
            feature_value = float(row[feature_col])
            target_value = row[target_col]

            if feature_value <= split_point:
                if target_value == "Yes":
                    left_yes += 1
                else:
                    left_no += 1
            else:
                if target_value == "Yes":
                    right_yes += 1
                else:
                    right_no += 1

        left_total = left_yes + left_no
        right_total = right_yes + right_no
        weighted_entropy = ((left_total / total_samples) * calculate_entropy(left_yes, left_no) +
                            (right_total / total_samples) * calculate_entropy(right_yes, right_no))
        weighted_gini = ((left_total / total_samples) * calculate_gini(left_yes, left_no) +
                         (right_total / total_samples) * calculate_gini(right_yes, right_no))

        info_gain = parent_entropy - weighted_entropy
        log_data.append(f"Split Point: {split_point}, Weighted Entropy: {weighted_entropy}, Gini Index: {weighted_gini}, Information Gain: {info_gain}")

        if info_gain > best_info_gain:
            best_info_gain = info_gain
            best_split = split_point
            best_final_gini = weighted_gini

    log_data.append(f"Best Split Point: {best_split} with Information Gain: {best_info_gain}")
    return best_final_gini

# Function to split and calculate for categorical data
def calculate_for_categorical(data, feature_col, target_col, target_count, log_data, parent_entropy, total_samples):
    feature_map = {}

    for row in data[1:]:
        feature_value = row[feature_col]
        target_value = row[target_col]
        if feature_value not in feature_map:
            feature_map[feature_value] = {"Yes": 0, "No": 0}
        feature_map[feature_value][target_value] += 1

    weighted_entropy = 0
    weighted_gini_index = 0
    for feature_value, counts in feature_map.items():
        feature_total = sum(counts.values())
        feature_entropy = sum((-p / feature_total) * math.log2(p / feature_total)
                              for p in counts.values() if p > 0)
        feature_gini = 1 - sum((p / feature_total) ** 2 for p in counts.values())

        weighted_entropy += (feature_total / total_samples) * feature_entropy
        weighted_gini_index += (feature_total / total_samples) * feature_gini

        log_data.append(f"Feature: {feature_value} | Weighted Entropy: {feature_entropy} | Gini Index: {feature_gini}")

    info_gain = parent_entropy - weighted_entropy
    log_data.append(f"Information Gain for Selected Feature: {info_gain}")
    return weighted_gini_index

def main():
    data = read_csv("12.gain_gini/input.csv")
    
    # User inputs
    target_col = int(input("Enter the index of the target column (0-indexed): "))
    feature_col = int(input("Enter the index of the feature column (0-indexed): "))

    if len(data) < 2 or target_col >= len(data[0]) or feature_col >= len(data[0]):
        print("Invalid input or no data found in the CSV file.")
        return

    target_count = {"Yes": 0, "No": 0}
    total_samples = len(data) - 1

    for row in data[1:]:
        target_count[row[target_col]] += 1

    parent_entropy = sum((-count / total_samples) * math.log2(count / total_samples)
                         for count in target_count.values() if count > 0)
    
    log_data = [f"Parent Entropy: {parent_entropy}"]

    if is_numeric(data[1][feature_col]):
        log_data.append("Numerical Feature Selected")
        best_final_gini = calculate_for_numerical(data, feature_col, target_col, target_count, log_data, parent_entropy, total_samples)
    else:
        log_data.append("Categorical Feature Selected")
        best_final_gini = calculate_for_categorical(data, feature_col, target_col, target_count, log_data, parent_entropy, total_samples)

    log_data.append(f"Final Gini Index after Best Split: {best_final_gini}")

    write_csv("12.gain_gini/output.csv", log_data)
    print("Results written to output.csv")

if __name__ == "__main__":
    main()
